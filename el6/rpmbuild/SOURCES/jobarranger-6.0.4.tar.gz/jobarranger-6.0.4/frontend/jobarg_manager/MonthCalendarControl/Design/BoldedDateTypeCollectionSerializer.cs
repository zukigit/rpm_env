﻿namespace CustomControls.Design
{
   using System.ComponentModel.Design.Serialization;

   internal class BoldedDateTypeCollectionSerializer : CollectionCodeDomSerializer 
   {
      protected override object SerializeCollection(IDesignerSerializationManager manager, System.CodeDom.CodeExpression targetExpression, System.Type targetType, System.Collections.ICollection originalCollection, System.Collections.ICollection valuesToSerialize)
      {
         return base.SerializeCollection(manager, targetExpression, targetType, originalCollection, valuesToSerialize);
      }
   }
}