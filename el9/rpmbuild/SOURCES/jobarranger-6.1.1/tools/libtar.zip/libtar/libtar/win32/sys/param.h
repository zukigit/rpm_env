#ifndef __SYS_PARAM_H__
#define __SYS_PARAM_H__

#include <stdlib.h>

#define MAXPATHLEN _MAX_PATH

#endif
