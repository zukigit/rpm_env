#ifndef __WIN32_TYPES_H__
#define __WIN32_TYPES_H__

typedef int ssize_t;
typedef int mode_t;
typedef int pid_t;
typedef int uid_t;
typedef int gid_t;

#endif
