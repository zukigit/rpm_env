/*
** Zabbix
** Copyright (C) 2000-2011 Zabbix SIA
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
**/

#ifdef _WINDOWS
#include "common.h"
#include "stats.h"
#include "perfstat.h"
#include "alias.h"
#include "log.h"
#include "mutexs.h"
ZBX_PERF_STAT_DATA ppsd;
static ZBX_MUTEX perfstat_access = ZBX_MUTEX_NULL;

static void deactivate_perf_counter(PERF_COUNTER_DATA * counter)
{

}

PERF_COUNTER_DATA *add_perf_counter(const char *name,
                                    const char *counterpath, int interval)
{
    return NULL;
}

void remove_perf_counter(PERF_COUNTER_DATA * counter)
{

}

static void free_perf_counter_list()
{

}

double compute_average_value(PERF_COUNTER_DATA * counter, int interval)
{
    return 0;
}

int init_perf_collector(int multithreaded)
{
    return SUCCEED;
}

int perf_collector_started()
{
    return SUCCEED;
}

void free_perf_collector()
{

}

void collect_perfstat()
{

}

#endif
