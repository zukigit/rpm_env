
-- Job Arranger drop table SQL for PostgreSQL  - 2014/09/17 -

-- Copyright (C) 2012 FitechForce, Inc. All Rights Reserved.
-- Copyright (C) 2013 Daiwa Institute of Research Business Innovation Ltd. All Rights Reserved.


DROP TABLE ja_calendar_control_table CASCADE;
DROP TABLE ja_calendar_detail_table CASCADE;
DROP TABLE ja_filter_control_table CASCADE;
DROP TABLE ja_schedule_control_table CASCADE;
DROP TABLE ja_schedule_detail_table CASCADE;
DROP TABLE ja_schedule_jobnet_table CASCADE;
DROP TABLE ja_jobnet_control_table CASCADE;
DROP TABLE ja_job_control_table CASCADE;
DROP TABLE ja_flow_control_table CASCADE;
DROP TABLE ja_icon_agentless_table CASCADE;
DROP TABLE ja_icon_calc_table CASCADE;
DROP TABLE ja_icon_end_table CASCADE;
DROP TABLE ja_icon_extjob_table CASCADE;
DROP TABLE ja_icon_fcopy_table CASCADE;
DROP TABLE ja_icon_fwait_table CASCADE;
DROP TABLE ja_icon_if_table CASCADE;
DROP TABLE ja_icon_info_table CASCADE;
DROP TABLE ja_icon_jobnet_table CASCADE;
DROP TABLE ja_icon_job_table CASCADE;
DROP TABLE ja_job_command_table CASCADE;
DROP TABLE ja_value_job_table CASCADE;
DROP TABLE ja_value_jobcon_table CASCADE;
DROP TABLE ja_icon_reboot_table CASCADE;
DROP TABLE ja_icon_release_table CASCADE;
DROP TABLE ja_icon_task_table CASCADE;
DROP TABLE ja_icon_value_table CASCADE;
DROP TABLE ja_icon_zabbix_link_table CASCADE;
DROP TABLE ja_define_value_jobcon_table CASCADE;
DROP TABLE ja_define_extjob_table CASCADE;
DROP TABLE ja_run_jobnet_summary_table CASCADE;
DROP TABLE ja_run_jobnet_table CASCADE;
DROP TABLE ja_run_job_table CASCADE;
DROP TABLE ja_run_flow_table CASCADE;
DROP TABLE ja_run_icon_agentless_table CASCADE;
DROP TABLE ja_run_icon_calc_table CASCADE;
DROP TABLE ja_run_icon_end_table CASCADE;
DROP TABLE ja_run_icon_extjob_table CASCADE;
DROP TABLE ja_run_icon_fcopy_table CASCADE;
DROP TABLE ja_run_icon_fwait_table CASCADE;
DROP TABLE ja_run_icon_if_table CASCADE;
DROP TABLE ja_run_icon_info_table CASCADE;
DROP TABLE ja_run_icon_jobnet_table CASCADE;
DROP TABLE ja_run_icon_job_table CASCADE;
DROP TABLE ja_run_job_command_table CASCADE;
DROP TABLE ja_run_value_job_table CASCADE;
DROP TABLE ja_run_value_jobcon_table CASCADE;
DROP TABLE ja_run_icon_reboot_table CASCADE;
DROP TABLE ja_run_icon_release_table CASCADE;
DROP TABLE ja_run_icon_task_table CASCADE;
DROP TABLE ja_run_icon_value_table CASCADE;
DROP TABLE ja_run_icon_zabbix_link_table CASCADE;
DROP TABLE ja_run_value_before_table CASCADE;
DROP TABLE ja_run_value_after_table CASCADE;
DROP TABLE ja_value_before_jobnet_table CASCADE;
DROP TABLE ja_value_after_jobnet_table CASCADE;
DROP TABLE ja_session_table CASCADE;
DROP TABLE ja_run_log_table CASCADE;
DROP TABLE ja_define_run_log_message_table CASCADE;
DROP TABLE ja_send_message_table CASCADE;
DROP TABLE ja_index_table CASCADE;
DROP TABLE ja_parameter_table CASCADE;
DROP TABLE ja_host_lock_table CASCADE;
DROP TABLE ja_object_lock_table CASCADE;
